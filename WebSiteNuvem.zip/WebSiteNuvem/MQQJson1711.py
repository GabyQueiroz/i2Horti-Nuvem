import json
import uuid
import ssl
from datetime import datetime

import boto3
import paho.mqtt.client as mqtt

# ============================
# Configuração MQTT AWS IoT
# ============================

mqtt_broker = "a1xb4e7ftt8wtn-ats.iot.us-east-1.amazonaws.com"
mqtt_port = 8883

mqtt_topic_previsao   = "previsao/simepar"
mqtt_topic_publish    = "irrigationRBS/schedule"
mqtt_topic_request    = "irrigationplan/request"
mqtt_topic_culturas   = "cultures/get"
mqtt_topic_canteiros  = "canteiros/get"
mqtt_topic_rl         = "irrigationRL/schedule"
mqtt_topic_plug_daily = "plugfield/forecast/daily"
mqtt_topic_plug_hour  = "plugfield/forecast/hourly"

mqtt_client_id = f"rasp-{uuid.uuid4()}"

mqtt_ca_path   = "/home/ubuntu/aws_iot/AmazonRootCA1.pem"
mqtt_cert_path = "/home/ubuntu/aws_iot/raspgaby.cert.pem"
mqtt_key_path  = "/home/ubuntu/aws_iot/raspgaby.private.key"

# ============================
# Configuração AWS / S3
# ============================

AWS_ACCESS_KEY = "AKIASK5MCJDSTXNA7B6M"
AWS_SECRET_KEY = "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"
BUCKET_NAME    = "raspbpibucket"
REGIAO         = "us-east-1"

# Cliente S3
s3 = boto3.client(
    "s3",
    region_name=REGIAO,
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
)

# Mapeia tópico -> arquivo no S3
TOPIC_TO_S3_KEY = {
    mqtt_topic_previsao:   "dashboard/previsao_simepar.json",
    mqtt_topic_canteiros:  "dashboard/canteiros_get.json",
    mqtt_topic_culturas:   "dashboard/cultures_get.json",
    mqtt_topic_publish:    "dashboard/irrigationRBS_schedule.json",
    mqtt_topic_request:    "dashboard/irrigationplan_request.json",
    mqtt_topic_rl:         "dashboard/irrigationRL_schedule.json",
    mqtt_topic_plug_daily: "dashboard/plugfield_forecast_daily.json",
    mqtt_topic_plug_hour:  "dashboard/plugfield_forecast_hourly.json",
}

# ============================
# Funções MQTT
# ============================

def on_connect(client, userdata, flags, reason_code, properties=None):
    print("Conectado ao broker, rc:", reason_code)

    if reason_code == 0:
        topics = [(t, 0) for t in TOPIC_TO_S3_KEY.keys()]
        client.subscribe(topics)
        print("Inscrito nos tópicos:", [t[0] for t in topics])
    else:
        print("Falha ao conectar:", reason_code)


def on_message(client, userdata, msg):
    topic = msg.topic
    payload_str = msg.payload.decode("utf-8", errors="ignore")
    print(f"\n[{datetime.now()}] Mensagem recebida em {topic}: {payload_str}")

    if topic not in TOPIC_TO_S3_KEY:
        print("Tópico sem mapeamento para S3, ignorando.")
        return

    s3_key = TOPIC_TO_S3_KEY[topic]

    # Tenta parsear JSON
    try:
        payload_obj = json.loads(payload_str)
        print(f"Tipo de payload: {type(payload_obj).__name__}")
    except json.JSONDecodeError:
        payload_obj = {"raw_payload": payload_str}

    if isinstance(payload_obj, list):
        payload_obj = {"data": payload_obj}

    if not isinstance(payload_obj, dict):
        payload_obj = {"value": payload_obj}

    payload_obj["_received_at"] = datetime.utcnow().isoformat() + "Z"
    payload_obj["_topic"] = topic

    body = json.dumps(payload_obj, ensure_ascii=False, indent=2)

    try:
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=s3_key,
            Body=body.encode("utf-8"),
            ContentType="application/json"
        )
        print(f"✅ Atualizado S3: s3://{BUCKET_NAME}/{s3_key}")
    except Exception as e:
        print("❌ Erro ao enviar para S3:", e)


# ============================
# Configura MQTT
# ============================

mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, mqtt_client_id)

mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

mqtt_client.tls_set(
    ca_certs=mqtt_ca_path,
    certfile=mqtt_cert_path,
    keyfile=mqtt_key_path,
    cert_reqs=ssl.CERT_REQUIRED,
    tls_version=ssl.PROTOCOL_TLS_CLIENT
)

mqtt_client.tls_insecure_set(False)

mqtt_client.connect(mqtt_broker, mqtt_port)
mqtt_client.loop_forever()
