#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import uuid
import ssl
from datetime import datetime, timezone

import boto3
import paho.mqtt.client as mqtt

# ============================
# Configuração MQTT AWS IoT
# ============================

mqtt_broker = "a1xb4e7ftt8wtn-ats.iot.us-east-1.amazonaws.com"
mqtt_port = 8883

mqtt_topic_previsao   = "previsao/simepar"
mqtt_topic_publish    = "irrigationRBS/schedule"
mqtt_topic_request    = "irrigationplan/request"
mqtt_topic_culturas   = "cultures/get"
mqtt_topic_canteiros  = "canteiros/get"
mqtt_topic_rl         = "irrigationRL/schedule"
mqtt_topic_plug_daily = "plugfield/forecast/daily"
mqtt_topic_plug_hour  = "plugfield/forecast/hourly"

mqtt_client_id = f"rasp-{uuid.uuid4()}"

mqtt_ca_path   = "/home/ubuntu/aws_iot/AmazonRootCA1.pem"
mqtt_cert_path = "/home/ubuntu/aws_iot/raspgaby.cert.pem"
mqtt_key_path  = "/home/ubuntu/aws_iot/raspgaby.private.key"

# ============================
# Configuração AWS / S3
# ============================

AWS_ACCESS_KEY = "AKIASK5MCJDSTXNA7B6M"
AWS_SECRET_KEY = "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"
BUCKET_NAME    = "raspbpibucket"
REGIAO         = "us-east-1"

# Cliente S3
s3 = boto3.client(
    "s3",
    region_name=REGIAO,
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
)

# Mapeia tópico -> arquivo S3 com o ÚLTIMO valor
TOPIC_TO_S3_KEY = {
    mqtt_topic_previsao:   "dashboard/previsao_simepar.json",
    mqtt_topic_canteiros:  "dashboard/canteiros_get.json",
    mqtt_topic_culturas:   "dashboard/cultures_get.json",
    mqtt_topic_publish:    "dashboard/irrigationRBS_schedule.json",
    mqtt_topic_request:    "dashboard/irrigationplan_request.json",
    mqtt_topic_rl:         "dashboard/irrigationRL_schedule.json",
    mqtt_topic_plug_daily: "dashboard/plugfield_forecast_daily.json",
    mqtt_topic_plug_hour:  "dashboard/plugfield_forecast_hourly.json",
}

# Prefixo para histórico
HISTORY_PREFIX = "dashboard/history"


def build_history_key(topic: str, received_dt: datetime) -> str:
    """
    Gera uma chave única de histórico no S3 para cada mensagem,
    organizada por tópico e por data (YYYY/MM/DD).

    Exemplo:
    dashboard/history/irrigationRL_schedule/2025/11/18/20251118T153000_123456Z.json
    """
    safe_topic = topic.replace("/", "_")  # ex: irrigationRL/schedule -> irrigationRL_schedule
    date_folder = received_dt.strftime("%Y/%m/%d")  # ex: 2025/11/18
    ts_str = received_dt.strftime("%Y%m%dT%H%M%S_%fZ")  # ex: 20251118T153045_123456Z
    return f"{HISTORY_PREFIX}/{safe_topic}/{date_folder}/{ts_str}.json"


# ============================
# Funções de callback MQTT
# ============================

def on_connect(client, userdata, flags, reason_code, properties=None):
    print("Conectado ao broker, rc:", reason_code)

    if reason_code == 0:
        # Inscreve em todos os tópicos da tabela
        topics = [(t, 0) for t in TOPIC_TO_S3_KEY.keys()]
        client.subscribe(topics)
        print("Inscrito nos tópicos:", [t[0] for t in topics])
    else:
        print("Falha ao conectar:", reason_code)


def on_message(client, userdata, msg):
    topic = msg.topic
    payload_str = msg.payload.decode("utf-8", errors="ignore")
    now_local = datetime.now()
    now_utc = datetime.now(timezone.utc)

    print(f"\n[{now_local}] Mensagem recebida em {topic}: {payload_str}")

    # Chave do arquivo "atual" (último valor) se existir mapeamento
    s3_key_atual = TOPIC_TO_S3_KEY.get(topic)

    # 1) Tenta parsear JSON
    try:
        payload_obj = json.loads(payload_str)
        print(f"Tipo de payload: {type(payload_obj).__name__}")
    except json.JSONDecodeError:
        # Se não for JSON válido, salva como texto bruto
        payload_obj = {"raw_payload": payload_str}

    # 2) Normalização para dicionário
    if isinstance(payload_obj, list):
        # Se for lista, embrulha em {"data": [...]}
        payload_obj = {"data": payload_obj}

    if not isinstance(payload_obj, dict):
        # Garante que será sempre dict
        payload_obj = {"value": payload_obj}

    # 3) Metadados padrão
    payload_obj["_received_at"] = now_utc.isoformat()
    payload_obj["_topic"] = topic

    body = json.dumps(payload_obj, ensure_ascii=False, indent=2).encode("utf-8")

    # ================================
    # (A) Atualiza o "arquivo atual"
    # ================================
    if s3_key_atual is not None:
        try:
            s3.put_object(
                Bucket=BUCKET_NAME,
                Key=s3_key_atual,
                Body=body,
                ContentType="application/json",
            )
            print(f"✅ Atualizado S3 (arquivo atual): s3://{BUCKET_NAME}/{s3_key_atual}")
        except Exception as e:
            print("❌ Erro ao enviar arquivo atual para S3:", e)
    else:
        print("⚠️ Tópico sem mapeamento em TOPIC_TO_S3_KEY para arquivo atual (mas será salvo no histórico).")

    # ================================
    # (B) Salva SEMPRE no histórico
    # ================================
    try:
        history_key = build_history_key(topic, now_utc)
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=history_key,
            Body=body,
            ContentType="application/json",
        )
        print(f"📚 Salvo histórico no S3: s3://{BUCKET_NAME}/{history_key}")
    except Exception as e:
        print("❌ Erro ao salvar histórico no S3:", e)


# ============================
# Configura e inicia MQTT
# ============================

mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, mqtt_client_id)

mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

mqtt_client.tls_set(
    ca_certs=mqtt_ca_path,
    certfile=mqtt_cert_path,
    keyfile=mqtt_key_path,
    cert_reqs=ssl.CERT_REQUIRED,
    tls_version=ssl.PROTOCOL_TLS_CLIENT,
)

mqtt_client.tls_insecure_set(False)

mqtt_client.connect(mqtt_broker, mqtt_port)
mqtt_client.loop_forever()
